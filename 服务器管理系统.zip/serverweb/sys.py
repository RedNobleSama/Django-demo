import psutil,time
import socket,math,pymysql

data= []
class system():
    @classmethod
    def ip(cls):
        # 获取本机的IP地址
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        data.append(ip)

    @classmethod
    def cpu(cls):
        cpu_count = psutil.cpu_count()
        print(cpu_count)
        data.append(cpu_count)

    @classmethod
    def memory(cls):
        memroy = (psutil.virtual_memory().total)/1024/1024/1024
        mem = round(memroy)#浮点数四舍五入取整
        print(mem)
        data.append(mem)

    @classmethod
    def disk(cls):
        ssd = round((psutil.disk_usage('/')[0])/1024/1024/1024)
        print(ssd)
        data.append(ssd)

system.ip()
system.cpu()
system.memory()
system.disk()

print(data)


connect = pymysql.connect(host='120.78.222.167', user='cyt', passwd='cyt1997511', db='server', charset='utf8')
cursor = connect.cursor()

sql = "insert into pc(ip,cpu,disk,memory) values ('%s','%s','%s','%s')"%(data[0],data[1],data[3],data[2])
cursor.execute(sql)
connect.commit()
connect.close()