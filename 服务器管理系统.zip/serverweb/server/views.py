from django.shortcuts import render
from django.shortcuts import redirect
from django.core.urlresolvers import reverse
from .models import User,Pc
import paramiko


# Create your views here.
def login(request):
    return render(request,'login.html')

def dologin(request):
    u = User.objects.get(username=request.POST['username'])
    if u.password == request.POST['password']:
        request.session['user'] = u.username
        return redirect(reverse(index))

def loginout(request):
    del request.session['user']
    return redirect(reverse(login))


def index(request):
    if request.session.get('user',None):
        list = Pc.objects.all()
        context ={"userlist":list}
        return render(request, 'userList.html',context)
    else:
        return redirect(reverse(login))


def addpc(request):
    if request.session.get('user', None):
        return render(request,'insert.html')
    else:
        return redirect(reverse(login))

def insertpc(request):
    ip = request.POST['userId']
    username = request.POST['userName']
    password = request.POST['userpassword']

    ssh = paramiko.Transport((ip, 22))
    ssh.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(ssh)
    localfile = "sys.py"
    remotefile = "/root/sys.py"
    sftp.put(localfile, remotefile)
    print("上传")
    ssh.close()

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # 防止连接未知主机报错
    ssh.connect(hostname=ip, username=username, password=password)
    # command = "free -m"
    command = "python3 sys.py "
    stdin, stdout, stderr = ssh.exec_command(command)
    res = stdout.read().decode()
    print(res)
    ssh.close()
    return redirect(reverse(index))


def updatepc(request,uid):
    if request.session.get('user', None):
        ob = Pc.objects.get(id=uid)
        context ={"userlist":ob}
        return render(request,'update.html',context)
    else:
        return redirect(reverse(login))
def editpc(request,uid):
    ob = Pc.objects.get(id=uid)
    ob.lable = request.POST['lb']
    ob.save()
    return redirect(reverse(index))


def deletepc(request,uid):
    ob = Pc.objects.get(id=uid)
    ob.delete()
    return redirect(reverse(index))
