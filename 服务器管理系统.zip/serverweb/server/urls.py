from django.conf.urls import url,include
from .views import login,index,loginout,dologin,addpc,editpc,insertpc,deletepc,updatepc

urlpatterns = [

    url(r'^$', index,name='index'),
    url(r'^login$', login,name='login'),
    url(r'^dologin$', dologin,name='dologin'),
    url(r'^loginout$', loginout,name='loginout'),
    url(r'^addpc$', addpc,name='addpc'),
    url(r'^insertpc$', insertpc,name='insertpc'),
    url(r'^updatepc/(?P<uid>[0-9]+)$', updatepc,name='updatepc'),
    url(r'^editpc/(?P<uid>[0-9]+)$', editpc,name='editpc'),
    url(r'^deletepc/(?P<uid>[0-9]+)$', deletepc,name='deletepc'),

]