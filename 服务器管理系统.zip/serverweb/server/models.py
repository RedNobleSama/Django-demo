from django.db import models

# Create your models here.
class User(models.Model):
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)

    def toDict(self):
        return {'id':self.id,'username':self.username,'password':self.password}

    class Meta:
        db_table = "user"  # 更改表名


class Pc(models.Model):
    ip = models.CharField(max_length=255)
    lable = models.CharField(max_length=255)
    cpu = models.CharField(max_length=255)
    disk = models.CharField(max_length=255)
    memory = models.CharField(max_length=255)
    state = models.IntegerField(max_length=255)

    def toDict(self):
        return {'id':self.id,'ip':self.ip,'cpu':self.cpu,'disk':self.disk,'memory':self.memory,'lable':self.lable,'state':self.state}

    class Meta:
        db_table = "pc"  # 更改表名