# -*- coding: utf-8 -*-
import scrapy
from CSDNcdu.items import CsdncduItem
from scrapy_redis.spiders import RedisSpider

class CsdnSpider(RedisSpider):
    name = 'csdn'
    #allowed_domains = ['edu.csdn.net']
    #start_urls = ['https://edu.csdn.net/course/detail/9789']
    redis_key = 'csdnspider:start_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(CsdnSpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        item = CsdncduItem()
        item['title'] = response.css('h1::text').extract_first()
        item['students'] = response.css('div.course_status span::text').extract_first()
        item['price'] = response.css('span.pr::text').extract_first()
        item['teacher'] = response.css('div.professor_header a img::attr(alt)').extract_first()
        dlist = response.css('div.J_outline_content')
        for v in dlist:
            item['content'] = v.css('span.ellipsis::text').extract()
        print(item)
        yield item