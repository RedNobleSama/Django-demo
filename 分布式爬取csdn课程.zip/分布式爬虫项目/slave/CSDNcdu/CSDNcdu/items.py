# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class CsdncduItem(scrapy.Item):

    title = scrapy.Field()  #课程标题
    time = scrapy.Field()   #课时
    teacher = scrapy.Field()    #讲师
    objects = scrapy.Field()    #适合人群
    students = scrapy.Field()   #学习人数
    price = scrapy.Field()      #价格
    content = scrapy.Field()    #课程大纲

