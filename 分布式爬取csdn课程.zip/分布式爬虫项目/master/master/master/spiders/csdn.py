# -*- coding: utf-8 -*-
import scrapy
from master.items import MasterItem

class CsdnSpider(scrapy.Spider):
    name = 'csdn'
    allowed_domains = ['edu.csdn.net']
    start_urls = ['https://edu.csdn.net/courses/k/p1']
    p = 1
    def parse(self, response):
        item = MasterItem()
        dlist = response.css('div.course_item')
        for v in dlist:
            item['url'] = v.css('a::attr(href)').extract_first()
            print(item)
            yield item

        self.p +=1
        if self.p < 10:
            next_url = "https://edu.csdn.net/courses/k/p"+str(self.p)#拼接下一页地址
            url = response.urljoin(next_url)#下一页地址
            yield  scrapy.Request(url=url,callback=self.parse)#递归调用
