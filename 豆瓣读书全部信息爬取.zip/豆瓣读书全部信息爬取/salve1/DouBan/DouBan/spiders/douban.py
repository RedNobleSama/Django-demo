# -*- coding: utf-8 -*-
import scrapy
from DouBan.items import DoubanItem
from scrapy_redis.spiders import RedisSpider

class DoubanSpider(RedisSpider):
    name = 'douban'
    #allowed_domains = ['book.douban.com']
    #start_urls = ['https://book.douban.com/tag/%E5%B0%8F%E8%AF%B4']
    redis_key = 'douban:start_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(DoubanSpider, self).__init__(*args, **kwargs)

    p=0
    def parse(self, response):

        item = DoubanItem()
        dlist = response.css('li.subject-item div.pic a::attr(href)').extract()
        for v  in dlist:
            item['url'] = v
            yield item

        self.p += 20
        if self.p < 1980:
            next_url = response.url + str(self.p)  # 拼接下一页地址
            url = response.urljoin(next_url)  # 下一页地址
            yield scrapy.Request(url=url, callback=self.parse)  # 递归调用
