# -*- coding: utf-8 -*-
import scrapy,re
from DouBan.items import DoubanItem
from scrapy_redis.spiders import RedisSpider


class DoubanSpider(RedisSpider):
    name = 'douban'
    #allowed_domains = ['book.douban.com']
    #start_urls = ['https://book.douban.com/subject/25862578/']
    redis_key = 'douban:middle_urls'

    def __init__(self, *args, **kwargs):
        # Dynamically define the allowed domains list.
        domain = kwargs.pop('domain', '')
        self.allowed_domains = filter(None, domain.split(','))
        super(DoubanSpider, self).__init__(*args, **kwargs)

    def parse(self, response):
        item = DoubanItem()
        item['id'] = ''.join(re.findall('https://book.douban.com/subject/(.*?)/',response.url))#id号
        item['title'] = response.selector.css('h1 span::text').extract_first()#书名
        item['author'] = str(response.selector.xpath('//div[@id="info"]/a/text()').extract_first()).replace('\n','').lstrip()#作者
        item['translator'] = response.selector.xpath('//div[@id="info"]/span/a/text()').extract_first()#译者
        dlist = response.css('#info').extract_first()
        item['original'] = ''.join(re.findall('<span class="pl">原作名.*?</span>(.*?)<br>',dlist))#原书名
        item['press'] = ''.join(re.findall('<a href="https://book.douban.com/series/.*?brand=1">(.*?)</a>',dlist))#出品方
        item['imprint'] = ''.join(re.findall('<span class="pl">出版年.*?</span>(.*?)<br>',dlist))#出版年
        item['pages'] = ''.join(re.findall('<span class="pl">页数.*?</span>(.*?)<br>',dlist))#页数
        item['price'] = ''.join(re.findall('<span class="pl">定价.*?</span>(.*?)<br>',dlist))#定价
        item['binding'] =''.join(re.findall('<span class="pl">装帧.*?</span>(.*?)<br>',dlist))#装帧
        item['isbn'] = ''.join(re.findall('<span class="pl">ISBN.*?</span>(.*?)<br>',dlist))#ISBN
        item['score'] = response.selector.css('div.rating_self strong::text').extract_first()#评分
        item['number'] = response.selector.css('span.pl a span::text').extract_first()#评论数
        item['series'] = response.selector.css('div.subject_show div a::text').extract_first()#丛书
        yield item




