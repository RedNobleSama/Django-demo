# -*- coding: utf-8 -*-
import scrapy,re
from DouBan.items import  DoubanItem

class DoubanSpider(scrapy.Spider):
    name = 'douban'
    allowed_domains = ['book.douban.com']
    start_urls = ['https://book.douban.com/tag/?view=type&icn=index-sorttags-all']

    def parse(self, response):
        URLstr = 'https://book.douban.com'

        item = DoubanItem()
        dlist = response.css('table.tagCol td a::attr(href)').extract()
        for v in dlist:
            item['url'] = URLstr + v
            yield (item)


