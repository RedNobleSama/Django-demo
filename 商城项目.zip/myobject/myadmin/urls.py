from django.conf.urls import url

from myadmin.views import index,users,type,goods,orders

urlpatterns = [
    # 后台首页
    url(r'^$', index.index, name="myadmin_index"),

    # 后台管理员路由
    url(r'^login$', index.login, name="myadmin_login"),
    url(r'^dologin$', index.dologin, name="myadmin_dologin"),
    url(r'^logout$', index.logout, name="myadmin_logout"),

    #会员信息管理的路由
    url(r'^users/(?P<pIndex>[1-9]+)$', users.index, name="myadmin_users_index"),#查看信息
    url(r'^users/add$', users.add, name="myadmin_users_add"),#添加信息
    url(r'^users/insert$', users.insert, name="myadmin_users_insert"),#执行添加
    url(r'^users/del/(?P<uid>[0-9]+)$', users.delete, name="myadmin_users_del"),#删除信息
    url(r'^users/edit/(?P<uid>[0-9]+)$', users.edit, name="myadmin_users_edit"),#编辑信息
    url(r'^users/update/(?P<uid>[0-9]+)$', users.update, name="myadmin_users_update"),#更新信息
    url(r'^users/passedit/(?P<uid>[0-9]+)$', users.passedit, name="myadmin_users_passedit"),#修改密码
    url(r'^users/passupdate/(?P<uid>[0-9]+)$', users.passupdate, name="myadmin_users_passupdate"),#执行修改密码
    #url(r'^users/usersearch$', users.usersearch, name="myadmin_users_usersearch"),#查询
    #url(r'^users/(?P<pIndex>[1-9]+)$', users.showlist, name="myadmin_users_showlist"),#分页操作


    #商品类别信息模型
    url(r'^type$', type.index, name="myadmin_type_index"),  # 查看信息
    url(r'^type/add/(?P<tid>[0-9]+)$', type.add, name="myadmin_type_add"),  # 添加信息
    url(r'^type/insert$', type.insert, name="myadmin_type_insert"),  # 执行添加
    url(r'^type/del/(?P<tid>[0-9]+)$', type.delete, name="myadmin_type_del"),  # 删除信息
    url(r'^type/edit/(?P<tid>[0-9]+)$', type.edit, name="myadmin_type_edit"),  # 执行删除
    url(r'^type/update/(?P<tid>[0-9]+)$', type.update, name="myadmin_type_update"),  # 更新信息

    # 商品信息管理的路由
    url(r'^goods/(?P<pIndex>[0-9]+)$', goods.index, name="myadmin_goods_index"),  # 查看信息
    url(r'^goods/add$', goods.add, name="myadmin_goods_add"),  # 添加信息
    url(r'^goods/insert$', goods.insert, name="myadmin_goods_insert"),  # 执行添加
    url(r'^goods/del/(?P<uid>[0-9]+)$', goods.delete, name="myadmin_goods_del"),  # 删除信息
    url(r'^goods/edit/(?P<uid>[0-9]+)$', goods.edit, name="myadmin_goods_edit"),  # 执行删除
    url(r'^goods/update/(?P<uid>[0-9]+)$', goods.update, name="myadmin_goods_update"),  # 更新信息
    #url(r'^goods/(?P<pIndex>[1-9]+)$', goods.showlist, name="myadmin_goods_showlist"),#分页操作

    # 订单信息管理路由
    url(r'^orders$', orders.index, name="myadmin_orders_index"),
    url(r'^orders/(?P<pIndex>[0-9]+)$', orders.index, name="myadmin_orders_index"),
    url(r'^orders/detail/(?P<oid>[0-9]+)$', orders.detail, name="myadmin_orders_detail"),
    url(r'^orders/state$', orders.state, name="myadmin_orders_state"),
]