from django.shortcuts import render
from django.http import HttpResponse
from common.models import  Users
from datetime import  datetime
from django.db.models import Q
from django.core.paginator import Paginator



#后台首页
def index(request,pIndex):
    # 浏览信息
    list = Users.objects.all()

    # 获取用户信息查询对象
    mod = Users.objects
    mywhere = []  # 定义一个用于存放搜索条件列表

    # 获取、判断并封装关keyword键搜索
    kw = request.GET.get("keyword", None)
    if kw:
        # 查询商品名中只要含有关键字的都可以
        list = mod.filter(name__contains=kw)
        mywhere.append("keyword=" + kw)
    else:
        list = mod.filter()

    # 获取、判断并封装商品状态state搜索条件
    state = request.GET.get('state', '')
    if state != '':
        list = list.filter(state=state)
        mywhere.append("state=" + state)

    p = Paginator(list, 1)
    if pIndex == "":
        pIndex = 1
    list2 = p.page(pIndex)
    plist = p.page_range
    context = {"userlist": list2, 'plist': plist, 'pIndex': pIndex,'mywhere': mywhere}
    return render(request, "myadmin/users/index.html", context)

def add(request):
    #添加信息
    return render(request, "myadmin/users/add.html")

def insert(request):
    try:
        ob = Users()
        ob.username = request.POST['username']
        ob.name = request.POST['name']
        #获取密码并md5加密
        import  hashlib
        m = hashlib.md5()
        m.update(bytes(request.POST['password'],encoding='utf8'))
        ob.password = m.hexdigest()
        ob.sex = request.POST['sex']
        ob.address = request.POST['address']
        ob.code = request.POST['code']
        ob.phone = request.POST['phone']
        ob.email = request.POST['email']
        ob.state = 1
        ob.save()
        context ={"info":"添加成功"}
    except Exception as err:
        print(err)
        context = {"info":"添加失败"}
    return render(request,"myadmin/info.html",context)

def delete(request,uid):
    #删除信息
    try:
        #获取要删除数据的ID
        ob = Users.objects.get(id=uid)
        ob.delete()
        context = {"info":"删除成功"}
    except Exception as err:
        print(err)
        context = {"info":"删除失败"}
    return render(request,"myadmin/info.html",context)


def edit(request,uid):
    #编辑信息
    try:
        #获取要修改数据的ID
        ob = Users.objects.get(id=uid)
        context = {"userlist":ob}
        return render(request,"myadmin/users/edit.html",context)
    except Exception as err:
        print(err)
        context = {"info":"无信息"}
        return render(request, "myadmin/info.html",context)

def update(request,uid):
    #执行编辑信息
    try:
        ob = Users.objects.get(id=uid)#获取需要修改的信息
        ob.name = request.POST['name']
        ob.sex = request.POST['sex']
        ob.address = request.POST['address']
        ob.code = request.POST['code']
        ob.phone = request.POST['phone']
        ob.email = request.POST['email']
        ob.state = request.POST['state']
        ob.save()
        context = {"info": "修改成功"}
    except Exception as err:
        print(err)
        context = {"info": "修改失败"}
    return render(request, "myadmin/info.html", context)

def passedit(request,uid):
    # 修改密码
    try:
        # 获取要修改数据的ID
        ob = Users.objects.get(id=uid)
        context = {"userlist": ob}
        return render(request, "myadmin/users/passupdate.html", context)
    except Exception as err:
        print(err)
        context = {"info": "无信息"}
        return render(request, "myadmin/info.html", context)

def passupdate(request,uid):
    # 执行编辑信息
    try:
        ob = Users.objects.get(id=uid) # 获取需要修改的信息

        # 获取密码并md5加密
        import hashlib
        m = hashlib.md5()
        m.update(bytes(request.POST['password'], encoding='utf8'))
        ob.password = m.hexdigest()

        ob.save()
        context = {"info": "修改成功"}
    except Exception as err:
        print(err)
        context = {"info": "修改失败"}
    return render(request, "myadmin/info.html", context)

def usersearch(request):
   pass


def showlist(request,pIndex):
    pass

