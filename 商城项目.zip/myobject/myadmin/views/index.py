from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.core.urlresolvers import reverse
from common.models import Users
import time,json

#后台首页
def index(request):
    #后台首页
    return render(request, "myadmin/index.html")

def login(requset):
    #加载登录页面
    return render(requset,"myadmin/login.html")

def dologin(request):
    #执行登录
    try:
        # 根据账号获取登录者信息
        user = Users.objects.get(username=request.POST['username'])
        # 判断当前用户是否是后台管理员用户
        if user.state == 0:
            # 验证密码
            import hashlib
            m = hashlib.md5()
            m.update(bytes(request.POST['password'], encoding="utf8"))
            if user.password == m.hexdigest():
                # 此处登录成功，将当前登录信息放入到session中，并跳转页面
                request.session['adminuser'] = user.name
                return redirect(reverse('myadmin_index'))
            else:
                context = {'info': '登录密码错误！'}
        else:
            context = {'info': '此用户非后台管理用户！'}
    except Exception as err:
        print(err)
        context = {'info': '登录账号错误！'}
    return render(request, "myadmin/login.html", context)

def logout(request):
    del request.session['adminuser']
    return  redirect(reverse('myadmin_login'))

