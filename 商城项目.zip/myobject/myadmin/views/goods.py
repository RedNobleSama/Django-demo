from django.shortcuts import render
from django.http import HttpResponse
from common.models import  Goods,Types
from PIL import Image
import time,os
from datetime import  datetime
from django.db.models import Q
from django.core.paginator import Paginator

#后台首页
def index(request,pIndex):
    #浏览信息
    list = Goods.objects.all()

    # 获取商品类别信息
    tlist = Types.objects.extra(select={'_has': 'concat(path,id)'}).order_by('_has')
    for ob in tlist:
        ob.pname = '. . .' * (ob.path.count(',') - 1)

    # 获取商品信息查询对象
    mod = Goods.objects
    mywhere = []  # 定义一个用于存放搜索条件列表

    # 获取、判断并封装关keyword键搜索
    kw = request.GET.get("keyword", None)
    if kw:
        # 查询商品名中只要含有关键字的都可以
        list = mod.filter(goods__contains=kw)
        mywhere.append("keyword=" + kw)
    else:
        list = mod.filter()
    # 获取、判断并封装商品类别typeid搜索条件
    typeid = request.GET.get('typeid', '0')
    if typeid != '0':
        tids = Types.objects.filter(Q(id=typeid) | Q(pid=typeid)).values_list('id', flat=True)
        list = list.filter(typeid__in=tids)
        mywhere.append("typeid=" + typeid)
    # 获取、判断并封装商品状态state搜索条件
    state = request.GET.get('state', '')
    if state != '':
        list = list.filter(state=state)
        mywhere.append("state=" + state)

    # 执行分页处理
    pIndex = int(pIndex)
    page = Paginator(list, 1)  # 以5条每页创建分页对象
    list2 = page.page(pIndex)  # 当前页数据
    plist = page.page_range  # 页码数列表

    #遍历商品信息，并获取对应的商品类别名称，以typename名封装
    for vo in list:
        ty = Types.objects.get(id=vo.typeid)
        vo.typename = ty.name
    context ={'typelist':tlist,"goodslist":list2,'plist':plist,'pIndex':pIndex,'mywhere':mywhere,'typeid':int(typeid)}
    return render(request, "myadmin/goods/index.html",context)

def add(request):
    #添加信息
    #获取商品类别信息
    tlist = Types.objects.extra(select={'_has':'concat(path,id)'}).order_by('_has')
    context = {"typelist":tlist}
    return render(request,'myadmin/goods/add.html',context)

def insert(request):
    try:
        '''执行图片的上传'''
        myfile = request.FILES.get("pic", None)
        if not myfile:
            return HttpResponse("没有上传文件信息")
        filename = str(time.time()) + "." + myfile.name.split('.').pop()
        destination = open("./static/pics/" + filename, "wb+")
        for chunk in myfile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()

        # 执行图片缩放
        im = Image.open("./static/pics/" + filename)
        # 缩放到75*75(缩放后的宽高比例不变):
        im.thumbnail((75, 75))
        # 把缩放后的图像用jpeg格式保存:
        im.save("./static/pics/a_" + filename, None)
        # 缩放到375*375(缩放后的宽高比例不变):
        im.thumbnail((375, 375))
        im.save("./static/pics/b_" + filename, None)
        # 缩放到220*220(缩放后的宽高比例不变):
        im.thumbnail((375, 375))
        im.save("./static/pics/c_" + filename, None)

        #保存商品信息
        ob = Goods()
        ob.goods = request.POST['goods']
        ob.typeid = request.POST['typeid']
        ob.company = request.POST['company']
        ob.price = request.POST['price']
        ob.store = request.POST['store']
        ob.content = request.POST['content']
        ob.picname = filename
        ob.state = 1
        ob.addtime = datetime.now()
        ob.save()
        context ={"info":"添加成功"}
    except Exception as err:
        print(err)
        context = {"info":"添加失败"}
    return render(request,"myadmin/info.html",context)

def delete(request,uid):
    #删除信息
    try:
        #获取要删除数据的ID
        ob = Goods.objects.get(id=uid)

        # 删除原图片
        img1 = "./static/pics/" + ob.picname
        img2 = "./static/pics/" + "a_" + ob.picname
        img3 = "./static/pics/" + "b_" + ob.picname
        img4 = "./static/pics/" + "c_" + ob.picname
        if os.path.exists(img1):
            os.remove(img1)
        if os.path.exists(img2):
            os.remove(img2)
        if os.path.exists(img3):
            os.remove(img3)
        if os.path.exists(img4):
            os.remove(img4)


        ob.delete()
        context = {"info":"删除成功"}
    except Exception as err:
        print(err)
        context = {"info":"删除失败"}
    return render(request,"myadmin/info.html",context)


def edit(request,uid):
    #编辑信息
    try:
        #获取要修改数据的ID
        ob = Goods.objects.get(id=uid)
        context = {"good":ob}
        return render(request,"myadmin/goods/edit.html",context)
    except Exception as err:
        print(err)
        context = {"info":"无信息"}
        return render(request, "myadmin/info.html",context)

def update(request,uid):
    #执行编辑信息
    try:
        ob = Goods.objects.get(id=uid)

        '''执行图片的上传'''
        myfile = request.FILES.get("pic", None)
        if not myfile:
            return HttpResponse("没有上传文件信息")
        filename = str(time.time()) + "." + myfile.name.split('.').pop()
        destination = open("./static/pics/" + filename, "wb+")
        for chunk in myfile.chunks():  # 分块写入文件
            destination.write(chunk)
        destination.close()

        # 执行图片缩放
        im = Image.open("./static/pics/" + filename)
        # 缩放到75*75(缩放后的宽高比例不变):
        im.thumbnail((75, 75))
        # 把缩放后的图像用jpeg格式保存:
        im.save("./static/pics/a_" + filename, None)
        # 缩放到375*375(缩放后的宽高比例不变):
        im.thumbnail((375, 375))
        im.save("./static/pics/b_" + filename, None)
        # 缩放到220*220(缩放后的宽高比例不变):
        im.thumbnail((375, 375))
        im.save("./static/pics/c_" + filename, None)

        # 删除原图片
        img1 = "./static/pics/" + ob.picname
        img2 = "./static/pics/" + "a_" + ob.picname
        img3 = "./static/pics/" + "b_" + ob.picname
        img4 = "./static/pics/" + "c_" + ob.picname
        if os.path.exists(img1):
            os.remove(img1)
        if os.path.exists(img2):
            os.remove(img2)
        if os.path.exists(img3):
            os.remove(img3)
        if os.path.exists(img4):
            os.remove(img4)



        ob.goods = request.POST["name"]
        ob.company = request.POST["company"]
        ob.price = request.POST["price"]
        ob.store = request.POST["store"]
        ob.content = request.POST["content"]
        ob.picname = filename
        ob.save()
        context = {"info": "修改成功"}
    except Exception as err:
        print(err)
        context = {"info": "修改失败"}
    return render(request, "myadmin/info.html", context)

def showlist(request,pIndex):
    pass