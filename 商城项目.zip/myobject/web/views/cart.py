from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.core.urlresolvers import reverse

from common.models import Goods,Types

#公共信息加载函数
def loadinfo(request):
    lists = Types.objects.filter(pid=0)
    context = {'typeliast':list}
    return context

 #浏览购物车
def index(request):
    context = loadinfo(request)
    if 'shoplist' not in request.session:
        request.session['shoplist'] = {}
    return  render(request,"web/cart/cart.html")

#添加购物车信息
def add(request,gid):
    goods = Goods.objects.get(id=gid)
    shop = goods.toDict()
    shop['m'] = int(request.POST.get("m",1))
    shoplist = request.session.get("shoplist",{})

    #判断购物车中是否已存在购买的商品
    if  gid in shoplist:
        shoplist[gid]['m'] += shop['m']#累计购买量
    else:
        shoplist[gid] = shop

    #将购物车中的商品信息放入到session中
    request.session['shoplist'] = shoplist
    return redirect(reverse('cart_index'))#跳转到购物车

#删除购物车信息
def delete(request,gid):
    shoplist = request.session['shoplist']
    del shoplist[gid]
    request.session['shoplist'] =shoplist
    return redirect(reverse('cart_index'))  # 跳转到购物车

#清空购物车信息
def clear(request):
    request.session['shoplist'] = {}
    return redirect(reverse('cart_index'))  # 跳转到购物车

#修改购物车信息
def change(request):
    shoplist = request.session['shoplist']#获取购物车信息
    shopid = request.GET.get("gid",0)#获取商品ID号
    num = int(request.GET.get('num',1))#获取要修改的数量
    if num<1:
        num =1
    shoplist[shopid]['m'] = num
    request.session['shoplist'] = shoplist
    return redirect(reverse('cart_index'))  # 跳转到购物车
