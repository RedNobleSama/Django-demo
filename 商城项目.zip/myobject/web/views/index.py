from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import redirect
from django.core.urlresolvers import reverse
from common.models import Users,Types,Goods
from django.core.paginator import Paginator

#公共信息加载函数
def loadinfo(request):
    list = Types.objects.filter(pid=0)
    context = {"typelist": list}
    return context

#前台首页
def index(request):
    context = loadinfo(request)
    return render(request,"web/index.html",context)

#商品列表页
def lists(request):
    context = loadinfo(request)
    #查询商品信息
    mod = Goods.objects

    tid = int(request.GET.get("tid",0))
    if tid > 0:
        list = mod.filter(typeid__in=Types.objects.only('id').filter(pid=tid))
    else:
        list = mod.first()



    context['goodslist'] = list
    return render(request,"web/list.html",context)

#商品详情页
def detail(request,gid):
    context = loadinfo(request)
    ob = Goods.objects.get(id=gid)
    ob.clicknum +=1
    ob.save()
    context['goods'] = ob
    return render(request, "web/detail.html",context)

def login(request):
    #会员登录界面
    return render(request, 'web/login.html')

def dologin(request):
    #会员执行登录
    try:
        # 根据账号获取登录者信息
        user = Users.objects.get(username=request.POST['username'])
        # 判断当前用户是否是后台管理员用户
        if user.state == 0 or user.state == 1:
            # 验证密码
            import hashlib
            m = hashlib.md5()
            m.update(bytes(request.POST['password'], encoding="utf8"))
            if user.password == m.hexdigest():
                # 此处登录成功，将当前登录信息放入到session中，并跳转页面
                request.session['vipuser'] = user.toDict()
                return redirect(reverse('index'))
            else:
                context = {'info': '登录密码错误！'}
        else:
            context = {'info': '此用户为非法用户！'}
    except:
        context = {'info': '登录账号错误！'}
    return render(request, "web/login.html", context)

def loginout(request):
    #会员退出
    # 清除登录的session信息
    del request.session['vipuser']
    # 跳转登录页面（url地址改变）
    return redirect(reverse('login'))


def registeadd(request):
    return render(request,"web/registe.html")

def registeinsert(request):
    ob = Users()
    ob.username = request.POST['username']
    ob.name = request.POST['name']
    #获取密码并md5加密
    import  hashlib
    m = hashlib.md5()
    m.update(bytes(request.POST['password'],encoding='utf8'))
    ob.password = m.hexdigest()
    ob.sex = request.POST['sex']
    ob.state = 1
    ob.save()
    return render(request,"web/login.html")

